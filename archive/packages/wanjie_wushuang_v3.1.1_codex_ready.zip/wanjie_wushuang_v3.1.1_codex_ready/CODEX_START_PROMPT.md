# CODEX_START_PROMPT.md

把整个项目目录作为 Codex 项目打开，然后直接发送下面这段：

---

先完整阅读根目录 `AGENTS.md`，然后阅读：
- `README.md`
- `docs/PRODUCT_SPEC.md`
- `docs/ARCHITECTURE.md`
- `docs/ACCEPTANCE_CRITERIA.md`
- `docs/ROADMAP.md`
- `docs/VALIDATION.md`

这是《万界无双》V3.1.1 Codex Ready 基线。

第一阶段不要添加新玩法。开始 V3.2 Phase 1：

1. 审计现有 JS 的全局变量、核心函数覆盖链和配置对象。
2. 输出 `docs/GLOBAL_RUNTIME_AUDIT.md`，列出：全局配置、全局状态、被多次override的函数、override顺序、高风险耦合点。
3. 在不改变现有玩法和脚本加载结果的前提下，引入 `window.WW` 根命名空间。
4. 先只迁移纯配置引用层：`WW.config.heroes / skills / bosses / stages / gear / runes / pets / modes`。
5. 保留旧全局别名，确保旧代码继续运行。
6. 不迁移 `run/player/enemies/shots/save`。
7. 不重写战斗循环。
8. 完成后运行：`npm run check`、`npm run smoke`、`npm run audit`。
9. 给出修改摘要、文件列表、验证结果、尚未迁移的全局状态、下一阶段建议。

如果发现P0/P1 bug，优先修复并说明，不要为了完成重构而掩盖它。
