/* ================= V3.1 ENGINEERING SPLIT ================= */
window.WW_PROJECT = Object.freeze({
  version: 'V3.1.1',
  codename: 'CODEX READY',
  schema: 30,
  architecture: 'ordered-global-runtime',
  note: 'V3.1 preserves V3.0 runtime behavior while splitting source by responsibility.'
});
const _v31RenderTop = renderTop;
renderTop = function(){
  _v31RenderTop();
  const chip = document.querySelector('.versionChip');
  if(chip) chip.textContent = 'V3.1.1 · CODEX READY';
};
window.addEventListener('load', () => {
  document.title = '万界无双 · V3.1.1 Codex Ready';
  const chip = document.querySelector('.versionChip');
  if(chip) chip.textContent = 'V3.1.1 · CODEX READY';
});
