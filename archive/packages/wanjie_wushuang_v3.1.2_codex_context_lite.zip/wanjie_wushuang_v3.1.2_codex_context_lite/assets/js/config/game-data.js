const HEROES={
 H001:{name:'赤焰战神',hp:620,atk:108,def:28,move:4.8,aspd:.95,crit:5,unlock:0,color:'#ef694e',skill:'炎龙斩',ult:'赤龙降世',
  presets:[['灭世炎狱',['A011','A021','A026','A027','A003','A054'],['P026','P017','P030','P019','P016','P018']],['炎龙武圣',['A001','A003','A054','A042','A063','A070'],['P016','P026','P011','P003','P019','P043']],['火域站场',['A021','A027','A028','A041','A011','A062'],['P017','P026','P027','P019','P043','P001']]]},
 H002:{name:'雷霆猛将',hp:520,atk:102,def:20,move:5.4,aspd:1.15,crit:8,unlock:800,color:'#70a9ff',skill:'雷闪突击',ult:'雷霆万军',
  presets:[['九天雷神',['A013','A022','A041','A051','A062','S003'],['P027','P023','P011','P018','P019','P003']],['雷枪连击',['A002','A051','A062','A013','A041','S003'],['P027','P011','P007','P003','P018','P019']],['雷影军团',['S003','A013','A022','A051','A041','A060'],['P027','P039','P036','P018','P011','P019']]]},
 H007:{name:'灵猴',hp:560,atk:105,def:22,move:5.4,aspd:1.10,crit:8,unlock:1200,color:'#f0b45d',skill:'腾云震地',ult:'法天象地',
  presets:[['斗战风暴',['A005','A001','A026','A045','S001','A009'],['P016','P011','P030','P039','P036','P018']],['万猴军团',['S001','A005','A026','A045','A060','A009'],['P039','P036','P037','P018','P016','P030']],['巨神棍阵',['A005','A001','A009','A045','A026','S001'],['P001','P016','P011','P019','P030','P043']]]},
 H010:{name:'炎忍',hp:440,atk:116,def:14,move:5.3,aspd:1.0,crit:6,unlock:0,color:'#f08358',skill:'炎龙疾走',ult:'炎龙忍法',
  presets:[['爆炎忍法',['A011','A019','A027','A054','S002','A042'],['P026','P010','P018','P019','P024','P033']],['炎龙疾走',['A054','A011','A027','A051','A060','S002'],['P026','P018','P011','P019','P033','P007']],['火分身',['S002','A011','A019','A027','A042','A063'],['P036','P039','P026','P010','P018','P019']]]},
 H012:{name:'影忍',hp:430,atk:106,def:14,move:5.6,aspd:1.20,crit:12,unlock:0,color:'#a47dff',skill:'影袭瞬杀',ult:'万影杀阵',
  presets:[['万影忍神',['A015','S001','A053','A070','A072','A073'],['P024','P039','P033','P007','P018','P019']],['暗器暴击',['A015','A007','A070','A053','A072','A073'],['P024','P007','P011','P019','P033','P018']],['影军召唤',['S001','A015','A053','A070','S002','S003'],['P039','P036','P033','P018','P019','P024']]]},
 H019:{name:'气功战士',hp:500,atk:112,def:18,move:5.2,aspd:1.05,crit:8,unlock:1500,color:'#65d8ff',skill:'爆气冲击',ult:'超级气功炮',
  presets:[['万象星河炮',['A014','A030','A049','A060','A068','S018'],['P032','P019','P018','P003','P016','P043']],['气爆领域',['A030','A060','A068','A014','A049','S018'],['P032','P016','P018','P019','P043','P001']],['百重气功',['A014','S018','A049','A068','A060','A030'],['P032','P019','P018','P003','P011','P016']]]}
};

const SKILLS={A001:'旋风斩',A002:'雷霆枪',A003:'烈焰刀',A005:'回旋棍',A007:'修罗斩',A009:'连环拳',A011:'火球术',A013:'雷电弹',A014:'气功弹',A015:'手里剑',A019:'爆裂弹',A021:'火焰领域',A022:'雷霆领域',A026:'龙卷风',A027:'陨石雨',A028:'爆炎阵',A030:'气爆领域',A041:'落雷',A042:'火柱',A045:'风刃雨',A049:'气功轰炸',A051:'雷闪',A053:'影袭',A054:'火焰冲刺',A060:'气爆瞬移',A062:'雷珠',A063:'火轮',A068:'气功珠',A070:'暗影刃',A072:'黑洞',A073:'镜像攻击',S001:'影分身',S002:'火分身',S003:'雷分身',S018:'气功幻影',P001:'力量强化',P003:'破军',P007:'致命',P010:'暴击爆炸',P011:'极速',P016:'范围强化',P017:'持续强化',P018:'冷却缩减',P019:'技能倍率',P023:'弹射',P024:'分裂',P026:'火神祝福',P027:'雷神祝福',P030:'风神祝福',P032:'气能强化',P033:'暗影强化',P036:'召唤强化',P037:'召唤速度',P039:'召唤数量',P043:'吸血'};
const EVOS={E001:['无双风暴','A001','P016'],E003:['炼狱龙斩','A003','P026'],E005:['斗战神棍','A005','P018'],E011:['炼狱火球','A011','P026'],E013:['无限雷链','A013','P023'],E014:['星河气弹','A014','P032'],E015:['万影手里剑','A015','P024'],E019:['连环爆破','A019','P010'],E021:['炼狱火海','A021','P017'],E022:['九天雷域','A022','P027'],E026:['天灾风暴','A026','P030'],E027:['天火陨星','A027','P026'],E028:['九重爆炎阵','A028','P019'],E030:['星环气场','A030','P032'],E041:['天罚神雷','A041','P027'],E049:['星河弹幕','A049','P032'],E054:['炎龙疾走','A054','P026'],SE001:['万影军团','S001','P039'],SE003:['雷神影军','S003','P027'],SE018:['星河幻影','S018','P032']};
const FUSIONS={F001:['焚天龙卷','E011','E026'],F002:['天火炼狱','E021','E027'],F003:['炎爆地狱','E028','E019'],F004:['炎龙乱舞','E003','E054'],F005:['雷神万影','E013','SE003'],F006:['九天雷劫','E022','E041'],F020:['百重气功炮','E014','SE018'],F021:['星河冲击','E030','E049'],F026:['无限影军','SE001','E015'],F033:['斗战风暴','E005','E001']};

const GEAR={
 EQW001:{name:'赤炎刀',slot:'weapon',score:310,rarity:'purple'},EQW003:{name:'玄铁棍',slot:'weapon',score:403,rarity:'gold'},EQW005:{name:'雷鸣枪',slot:'weapon',score:350,rarity:'purple'},EQW007:{name:'夜鸦千刃',slot:'weapon',score:440,rarity:'gold'},
 EQA001:{name:'武将甲',slot:'armor',score:220,rarity:'blue'},EQA003:{name:'斗战战甲',slot:'armor',score:380,rarity:'gold'},EQA005:{name:'影忍轻甲',slot:'armor',score:300,rarity:'purple'},EQA007:{name:'灵界战衣',slot:'armor',score:420,rarity:'gold'},
 EQX001:{name:'炎龙核心',slot:'accessory',score:250,rarity:'purple'},EQX003:{name:'万界印记',slot:'accessory',score:390,rarity:'gold'},EQX005:{name:'天机玉佩',slot:'accessory',score:210,rarity:'blue'},EQX007:{name:'混沌指环',slot:'accessory',score:430,rarity:'gold'}
};
const RUNES={R031:{name:'火神符文',score:95},R012:{name:'巨化符文',score:82},R043:{name:'学者符文',score:76},R001:{name:'狂战符文',score:88},R017:{name:'多重符文',score:90},R021:{name:'吸血符文',score:78}};
const PETS={PET001:{name:'火灵',score:140},PET002:{name:'雷狼',score:120},PET007:{name:'治疗精灵',score:110},PET011:{name:'招财猫',score:105},PET015:{name:'镜像精灵',score:128}};

const ENEMIES={
 EN001:{name:'黄巾步卒',map:'ST001',ai:'melee',hp:70,speed:68,damage:8,color:'#a84b43'},
 EN002:{name:'黄巾弓手',map:'ST001',ai:'ranged',hp:55,speed:54,damage:7,color:'#9d6a44'},
 EN003:{name:'黄巾盾兵',map:'ST001',ai:'shield',hp:145,speed:45,damage:7,color:'#6e737c'},
 EN004:{name:'黄巾骑兵',map:'ST001',ai:'charge',hp:105,speed:86,damage:12,color:'#8d4b3b'},
 EN005:{name:'火箭兵',map:'ST001',ai:'aoe_ranged',hp:65,speed:48,damage:9,color:'#b45d3d'},
 EN006:{name:'黄巾力士',map:'ST001',ai:'brute',hp:220,speed:38,damage:16,color:'#b2844f'},
 EN014:{name:'猴妖',map:'ST003',ai:'melee',hp:85,speed:76,damage:9,color:'#8e6b40'},
 EN015:{name:'狼妖',map:'ST003',ai:'flank',hp:72,speed:95,damage:10,color:'#6c6f75'},
 EN016:{name:'蛇妖',map:'ST003',ai:'poison',hp:68,speed:66,damage:8,color:'#5e8a58'},
 EN017:{name:'牛妖',map:'ST003',ai:'brute',hp:260,speed:40,damage:18,color:'#825947'},
 EN018:{name:'飞妖',map:'ST003',ai:'fly',hp:62,speed:82,damage:8,color:'#7b6f92'},
 EN019:{name:'妖术师',map:'ST003',ai:'summoner',hp:90,speed:45,damage:7,color:'#77508d'},
 EN020:{name:'石妖',map:'ST003',ai:'shield',hp:210,speed:36,damage:12,color:'#77756b'},
 EN021:{name:'下忍',map:'ST004',ai:'melee',hp:78,speed:84,damage:9,color:'#6d596f'},
 EN022:{name:'暗器忍',map:'ST004',ai:'ranged',hp:60,speed:74,damage:8,color:'#64567b'},
 EN023:{name:'火忍',map:'ST004',ai:'aoe_ranged',hp:72,speed:68,damage:10,color:'#9a4f3d'},
 EN024:{name:'雷忍',map:'ST004',ai:'dash',hp:74,speed:90,damage:11,color:'#5573a1'},
 EN025:{name:'分身忍',map:'ST004',ai:'clone',hp:82,speed:72,damage:8,color:'#705d84'},
 EN026:{name:'爆符忍',map:'ST004',ai:'trap',hp:65,speed:65,damage:12,color:'#8c593d'},
 EN027:{name:'医忍',map:'ST004',ai:'healer',hp:95,speed:55,damage:5,color:'#5b8c76'}
};

const BOSSES={
 B001:{name:'黄巾巨将',map:'ST001',style:'巨斧冲击',hp:7000,color:'#8f3539',skills:['震地斩','狂暴冲锋','旋风斧']},
 B002:{name:'乱世妖师',map:'ST001',style:'法阵与召唤',hp:11000,color:'#76538f',skills:['火符法阵','妖兵召唤','瞬移雷击']},
 B003:{name:'混沌骑将',map:'ST001',style:'骑乘冲锋',hp:18000,color:'#8a472d',skills:['直线冲锋','枪阵','下马狂战']},
 B006:{name:'牛魔妖王',map:'ST003',style:'重击与岩爆',hp:22000,color:'#76513a',skills:['裂地重锤','岩石爆破','霸体冲撞']},
 B008:{name:'混世魔猿',map:'ST003',style:'跳跃与分身',hp:30000,color:'#805f39',skills:['跃击','棍影分身','狂暴连砸']},
 B009:{name:'炎狱忍王',map:'ST004',style:'火遁与爆符',hp:24000,color:'#9a4539',skills:['炎墙','爆符雨','炎龙突袭']},
 B010:{name:'雷瞬忍王',map:'ST004',style:'高速雷闪',hp:26000,color:'#4f6d9c',skills:['雷瞬','雷牢','天雷落']},
 B011:{name:'万影忍王',map:'ST004',style:'分身与斩杀',hp:36000,color:'#70528d',skills:['万影分身','暗影扇刃','影界处刑']}
};

const CHAPTERS={
 ST001:{name:'乱世荒原',desc:'黄巾残军与裂隙妖术肆虐边境。',pos:[18,67],mechanic:'火线：周期出现横向燃烧带，站在其中持续掉血。',bossPool:['B001','B002','B003'],stages:[
  ['ST001-01','边境清剿',false,260,'B001'],['ST001-02','废村救援',false,320,'B001'],['ST001-03','妖师祭坛',true,420,'B002'],['ST001-04','裂隙骑将',true,650,'B003']
 ]},
 ST003:{name:'花果妖岭',desc:'妖气笼罩古道，混世魔猿统领怪潮。',pos:[52,37],mechanic:'妖雾：周期覆盖区域，降低视野并强化妖怪移速。',bossPool:['B006','B008'],stages:[
  ['ST003-01','妖岭入口',false,420,'B006'],['ST003-02','白骨迷阵',false,480,'B006'],['ST003-03','牛魔试炼',true,620,'B006'],['ST003-04','混世魔猿',true,820,'B008']
 ]},
 ST004:{name:'忍界战场',desc:'雷火、暗器与分身制造高速战场。',pos:[83,58],mechanic:'爆符区：地面随机生成爆符预警圈，延迟后爆炸。',bossPool:['B009','B010','B011'],stages:[
  ['ST004-01','暗器封锁',false,540,'B009'],['ST004-02','爆符峡谷',false,620,'B010'],['ST004-03','炎雷双王',true,820,'B010'],['ST004-04','万影忍王',true,1100,'B011']
 ]}
};

const ELITE_AFFIXES=[
 {id:'swift',name:'迅捷',desc:'移速+35%',apply:e=>{e.speed*=1.35}},
 {id:'tank',name:'坚甲',desc:'生命+80%',apply:e=>{e.hp*=1.8;e.maxHp*=1.8}},
 {id:'volatile',name:'爆裂',desc:'死亡爆炸',apply:e=>{e.volatile=true}},
 {id:'vamp',name:'吸血',desc:'命中回复',apply:e=>{e.vamp=true}},
 {id:'aura',name:'压制光环',desc:'靠近降低玩家移速',apply:e=>{e.aura=true}},
 {id:'split',name:'分裂',desc:'死亡分裂',apply:e=>{e.split=true}}
];

const MAP_EVENTS=[
 {id:'merchant',name:'万界游商',desc:'用金币购买一次局内强化。'},
 {id:'altar',name:'战神祭坛',desc:'获得强力增益，但附带代价。'},
 {id:'goldChest',name:'黄金宝箱',desc:'直接获得技能升级或装备掉落。'},
 {id:'rift',name:'时空裂缝',desc:'召唤精英怪，胜利后获得高品质奖励。'}
];

const SAVE_KEY='wanjie_v18_alpha_content';
const DEFAULT_SAVE={
 accountLv:12,gold:6000,hero:'H001',
 heroes:{H001:{unlocked:true,level:6,mastery:40},H002:{unlocked:false,level:1,mastery:0},H007:{unlocked:false,level:1,mastery:0},H010:{unlocked:true,level:4,mastery:20},H012:{unlocked:true,level:5,mastery:28},H019:{unlocked:false,level:1,mastery:0}},
 equip:{weapon:'EQW001',armor:'EQA001',accessory:'EQX001'},runes:['R031','R012','R043'],pet:'PET001',
 build:{active:['A011','A021','A026','A027','A003','A054'],passive:['P026','P017','P030','P019','P016','P018']},
 chapters:{ST001:{stars:{'ST001-01':3,'ST001-02':2,'ST001-03':0,'ST001-04':0}},ST003:{stars:{}},ST004:{stars:{}}},
 selectedChapter:'ST001',selectedStage:'ST001-03',
 inventory:{gear:['EQW001','EQW003','EQW005','EQA001','EQA003','EQA005','EQX001','EQX003','EQX005'],runes:['R031','R012','R043','R001','R017','R021'],pets:['PET001','PET002','PET007','PET011','PET015']},
 stats:{runs:4,kills:1840,bossKills:9},
 settings:{shake:true,numbers:true,particles:true,vignette:true,tutorialSeen:false}
};

function clone(x){return JSON.parse(JSON.stringify(x))}
function merge(a,b){for(const k in b){if(b[k]&&typeof b[k]==='object'&&!Array.isArray(b[k])&&a[k]&&typeof a[k]==='object'&&!Array.isArray(a[k]))a[k]=merge(a[k],b[k]);else a[k]=b[k]}return a}
function loadSave(){try{return merge(clone(DEFAULT_SAVE),JSON.parse(localStorage.getItem(SAVE_KEY)||'{}'))}catch(e){return clone(DEFAULT_SAVE)}}
let save=loadSave(),lastResult=null;
function persist(){recomputeWorldUnlocks();localStorage.setItem(SAVE_KEY,JSON.stringify(save));renderAll()}
function toast(m){const t=document.getElementById('toast');t.textContent=m;t.classList.add('show');clearTimeout(window.tt);window.tt=setTimeout(()=>t.classList.remove('show'),1600)}
function hint(m){const t=document.getElementById('eventHint');t.textContent=m;t.classList.add('show');clearTimeout(window.hh);window.hh=setTimeout(()=>t.classList.remove('show'),1700)}
function log(m){const d=document.createElement('div');d.textContent=m;const l=document.getElementById('battleLog');l.prepend(d);while(l.children.length>14)l.lastChild.remove()}
function fmt(sec){let m=Math.floor(sec/60),s=Math.floor(sec%60);return String(m).padStart(2,'0')+':'+String(s).padStart(2,'0')}
function go(id){document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));document.querySelectorAll('.nav button[data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===id));document.getElementById(id).classList.add('active');document.getElementById('pageTitle').textContent={home:'主大厅',heroes:'英雄',loadout:'装备局外',build:'Build',world:'世界地图',battle:'战斗',result:'结算'}[id]||'万界无双';if(id==='battle')resizeArena()}
document.querySelectorAll('.nav button[data-page]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.page)));

function chapterStars(id){return Object.values(save.chapters[id]?.stars||{}).reduce((a,b)=>a+(b||0),0)}
function totalStars(){return Object.keys(CHAPTERS).reduce((a,id)=>a+chapterStars(id),0)}
function recomputeWorldUnlocks(){CHAPTERS.ST001.unlock=true;CHAPTERS.ST003.unlock=chapterStars('ST001')>=8;CHAPTERS.ST004.unlock=chapterStars('ST003')>=8}
function gearScore(){return Object.values(save.equip).reduce((s,id)=>s+(GEAR[id]?.score||0),0)}
function runeScore(){return save.runes.reduce((s,id)=>s+(RUNES[id]?.score||0),0)}
function petScore(){return PETS[save.pet]?.score||0}
function buildScore(){const e=reachableBuildEvos().length,f=reachableBuildFusions().length;return Math.round(save.build.active.length*70+save.build.passive.length*45+e*35+f*75)}
function combatPower(){const h=save.heroes[save.hero];return Math.round(1200+save.accountLv*70+(h.level-1)*110+gearScore()*1.7+runeScore()*2.1+petScore()*2+buildScore()*.55)}
function heroStats(id){const h=HEROES[id],s=save.heroes[id],lv=1+(s.level-1)*.04;return {hp:Math.round(h.hp*(1+(s.level-1)*.03)),atk:Math.round(h.atk*lv),def:Math.round(h.def*(1+(s.level-1)*.02)),move:h.move,aspd:h.aspd,crit:h.crit}}
function skillName(id){return SKILLS[id]||EVOS[id]?.[0]||FUSIONS[id]?.[0]||id}
function glyph(id){return skillName(id).slice(0,1)}
function reachableBuildEvos(){return Object.entries(EVOS).filter(([id,[n,a,p]])=>save.build.active.includes(a)&&save.build.passive.includes(p)).map(([id])=>id)}
function reachableBuildFusions(){const e=new Set(reachableBuildEvos());return Object.entries(FUSIONS).filter(([id,[n,a,b]])=>e.has(a)&&e.has(b)).map(([id])=>id)}
function selectedStageInfo(){for(const [cid,c] of Object.entries(CHAPTERS)){for(const st of c.stages)if(st[0]===save.selectedStage)return {chapter:cid,stage:st}}return {chapter:'ST001',stage:CHAPTERS.ST001.stages[0]}}
function worldProgress(){return Math.round(totalStars()/36*100)}

function renderTop(){
 const si=selectedStageInfo();document.getElementById('topLv').textContent=save.accountLv;document.getElementById('topPower').textContent=combatPower().toLocaleString();document.getElementById('topGold').textContent=save.gold.toLocaleString();document.getElementById('topStars').textContent=totalStars();
 document.getElementById('homeHero').textContent=HEROES[save.hero].name;document.getElementById('homeStage').textContent=save.selectedStage;document.getElementById('homeBoss').textContent=si.stage[4];document.getElementById('homeGear').textContent=gearScore();document.getElementById('homeBuild').textContent=buildScore();document.getElementById('homeWorld').textContent=worldProgress()+'%'
}
function continueFlow(){go('heroes')}
