/* ================= V2.9 SEVEN PLAYABLE MODES ================= */
const V29_MODES={
 story:{name:'剧情模式',icon:'章',desc:'标准章节推进。20分钟内成长、进化、融合并完成区域Boss目标。',duration:1200,reward:1.00,tokens:2,spawn:1.00,hp:1.00,dmg:1.00,speed:1.00,bossAt:720,tags:['章节星','剧情推进','标准规则']},
 clear:{name:'通关模式',icon:'破',desc:'15分钟压缩战斗。刷怪更快，Boss提前登场，适合快速刷装备。',duration:900,reward:1.22,tokens:5,spawn:1.18,hp:1.08,dmg:1.06,speed:1.03,bossAt:600,tags:['15分钟','加速刷图','奖励+22%']},
 endless:{name:'无尽模式',icon:'∞',desc:'没有自动终点。敌人持续增强，每10分钟迎来一名Boss；10分钟后可主动撤离。',duration:null,reward:1.12,tokens:0,spawn:1.15,hp:1.06,dmg:1.05,speed:1.02,bossAt:600,tags:['无限生存','周期Boss','最佳时间']},
 bossrush:{name:'Boss Rush',icon:'王',desc:'连续挑战8名首领。普通怪物大幅减少，每名Boss保留三阶段机制与专属掉落。',duration:1080,reward:1.80,tokens:22,spawn:.18,hp:1.10,dmg:1.08,speed:1.04,bossAt:2,tags:['8 Boss','连续首领','专属掉落']},
 tower:{name:'万界塔',icon:'塔',desc:'按当前层数进行6分钟挑战。层数越高，敌人与Boss倍率持续成长。',duration:360,reward:1.35,tokens:4,spawn:1.12,hp:1.05,dmg:1.04,speed:1.02,bossAt:270,tags:['6分钟','逐层强化','永久层数']},
 daily:{name:'每日挑战',icon:'日',desc:'每天固定一套挑战词缀，12分钟完成；记录当天最高分。',duration:720,reward:1.55,tokens:10,spawn:1.22,hp:1.16,dmg:1.12,speed:1.05,bossAt:540,tags:['每日词缀','12分钟','每日记录']},
 abyss:{name:'深渊挑战',icon:'渊',desc:'15分钟高压终局模式。Director更激进，治疗效率降低，Boss与精英更强。',duration:900,reward:2.00,tokens:18,spawn:1.48,hp:1.55,dmg:1.38,speed:1.10,bossAt:600,tags:['高压终局','治疗削弱','奖励×2']}
};
const V29_BOSS_ORDER=['B001','B002','B003','B006','B008','B009','B010','B011'];
const V29_BOSS_STAGE={B001:'ST001-01',B002:'ST001-03',B003:'ST001-04',B006:'ST003-03',B008:'ST003-04',B009:'ST004-01',B010:'ST004-03',B011:'ST004-04'};
const V29_DAILY=[
 {name:'雷暴日',desc:'敌人移动更快，雷系Build获得强化；奖励额外+8%。',spawn:1.05,hp:1,dmg:1.05,speed:1.12,player:{lightning:.18},reward:.08},
 {name:'精英潮',desc:'精英密度显著提高，Boss伤害+10%；奖励额外+12%。',spawn:1.12,hp:1.06,dmg:1.08,speed:1.03,elite:1.8,player:{boss:.10},reward:.12},
 {name:'玻璃神兵',desc:'玩家攻击+28%，最大生命-25%，战斗更偏向快速击杀。',spawn:1.08,hp:1.10,dmg:1.12,speed:1.03,player:{atk:.28,hp:-.25},reward:.10},
 {name:'丰收怪潮',desc:'刷怪速度提高，金币与高品质掉落倾向增加。',spawn:1.32,hp:1.04,dmg:1.04,speed:1.02,player:{gold:.18,drop:.10},reward:.08}
];
function v29DateKey(){let d=new Date();return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
function v29Daily(){let d=new Date(),n=Math.floor((Date.UTC(d.getFullYear(),d.getMonth(),d.getDate())-Date.UTC(d.getFullYear(),0,0))/86400000);return V29_DAILY[n%V29_DAILY.length]}
function v29Ensure(){
 v28Ensure();if(!V29_MODES[save.mode])save.mode='story';if(save.modeTokens==null)save.modeTokens=0;save.modeStats=save.modeStats||{};
 for(const id of Object.keys(V29_MODES))save.modeStats[id]=save.modeStats[id]||{runs:0,wins:0,bestTime:0,bestKills:0,bestScore:0};
 if(save.modeStats.tower.floor==null)save.modeStats.tower.floor=1;if(save.modeStats.tower.bestFloor==null)save.modeStats.tower.bestFloor=1;if(save.modeStats.bossrush.bestBosses==null)save.modeStats.bossrush.bestBosses=0;if(save.modeStats.daily.lastDate==null)save.modeStats.daily.lastDate=''
}
function v29Rule(id=save.mode){
 let base={...V29_MODES[id]},floor=save.modeStats?.tower?.floor||1;
 if(id==='tower'){base.hp*=1+(floor-1)*.075;base.dmg*=1+(floor-1)*.05;base.speed*=1+Math.min(.25,(floor-1)*.008);base.spawn*=1+Math.min(.45,(floor-1)*.025);base.reward+=Math.min(1.2,(floor-1)*.035);base.tokens+=Math.floor((floor-1)/3)}
 if(id==='daily'){let d=v29Daily();base.spawn*=d.spawn;base.hp*=d.hp;base.dmg*=d.dmg;base.speed*=d.speed;base.reward+=d.reward||0;base.daily=d}
 return base
}
function v29Unlocked(id){
 recomputeWorldUnlocks();let stars=totalStars();
 if(id==='story')return[true,'默认开放'];if(id==='clear')return[stars>=3,'需要章节星 ≥ 3'];if(id==='endless')return[stars>=5,'需要章节星 ≥ 5'];
 if(id==='bossrush')return[(save.stats?.bossKills||0)>=3||save.accountLv>=8,'击败3个Boss或账号Lv.8'];if(id==='tower')return[save.accountLv>=10,'账号Lv.10'];
 if(id==='daily')return[save.accountLv>=15,'账号Lv.15'];if(id==='abyss')return[!!CHAPTERS.ST004.unlock&&save.accountLv>=20,'解锁忍界战场 + 账号Lv.20'];return[false,'未开放']
}
function v29RecordRows(id){let s=save.modeStats[id],rows=[['挑战次数',s.runs||0],['胜利次数',s.wins||0]];if(id==='endless')rows.push(['最佳生存',s.bestTime?fmt(s.bestTime):'—'],['最高击杀',s.bestKills||0]);else if(id==='bossrush')rows.push(['最快通关',s.bestTime?fmt(s.bestTime):'—'],['最多Boss',s.bestBosses||0]);else if(id==='tower')rows.push(['当前层',s.floor||1],['最高层',s.bestFloor||1]);else if(id==='daily')rows.push(['今日最高分',s.lastDate===v29DateKey()?(s.bestScore||0):0],['记录日期',s.lastDate||'—']);else rows.push(['最佳时间',s.bestTime?fmt(s.bestTime):'—'],['最高评分',s.bestScore||0]);return rows}
function v29RenderModes(){
 v29Ensure();let id=save.mode,r=v29Rule(id),cm=document.getElementById('v29CurrentMode');if(!cm)return;cm.textContent=r.name;document.getElementById('v29CurrentDesc').textContent=r.desc;document.getElementById('v29CurrentTime').textContent=r.duration?fmt(r.duration):'无限';document.getElementById('v29CurrentReward').textContent='×'+r.reward.toFixed(2);document.getElementById('v29Tokens').textContent=save.modeTokens;document.getElementById('v29CurrentDiff').textContent=v19Difficulty().name;
 let mb=document.getElementById('v29MutatorBox');mb.style.display=id==='daily'?'block':'none';if(id==='daily'){let d=v29Daily();document.getElementById('v29MutatorName').textContent='今日词缀 · '+d.name;document.getElementById('v29MutatorDesc').textContent=d.desc}
 document.getElementById('v29RecordRows').innerHTML=v29RecordRows(id).map(([a,b])=>'<div class="modeRecordRow"><span>'+a+'</span><b>'+b+'</b></div>').join('');
 let g=document.getElementById('v29ModeGrid');g.innerHTML='';for(const [mid,m] of Object.entries(V29_MODES)){let [ok,why]=v29Unlocked(mid),rr=v29Rule(mid),d=document.createElement('div');d.className='modeCard '+(mid===id?'selected ':'')+(ok?'':'locked');d.innerHTML='<div class="modeIcon">'+m.icon+'</div><div class="eyebrow">'+mid.toUpperCase()+'</div><h3>'+m.name+'</h3><p>'+m.desc+'</p><div class="modeTags">'+m.tags.map(x=>'<span>'+x+'</span>').join('')+'</div><div class="modeUnlock">'+(ok?'已开放 · '+(rr.duration?fmt(rr.duration):'无限')+' · 奖励×'+rr.reward.toFixed(2):'锁定 · '+why)+'</div><div class="actions"><button class="btn '+(mid===id?'gold':'ghost')+'" '+(ok?'':'disabled')+' onclick="v29SelectMode(\''+mid+'\')">'+(mid===id?'当前模式':'选择')+'</button>'+(ok?'<button class="btn primary" onclick="v29QuickStart(\''+mid+'\')">开始</button>':'')+'</div>';g.appendChild(d)}
}
function v29SelectMode(id){let [ok,why]=v29Unlocked(id);if(!ok)return toast(why);save.mode=id;persist();v29RenderModes();renderTop();toast('模式：'+V29_MODES[id].name)}
function v29QuickStart(id){let [ok,why]=v29Unlocked(id);if(!ok)return toast(why);save.mode=id;persist();startBattle()}
function v29StartSelected(){v29QuickStart(save.mode)}

function v29RuntimeInit(){let rule=v29Rule();run.v29={id:save.mode,rule,bossesKilled:0,lastBossSeen:null,countedBoss:null,endlessBossMilestone:0,score:0,daily:rule.daily||null}}
function v29Progress(){if(!run?.v29)return 0;let r=run.v29.rule;if(run.v29.id==='bossrush')return run.v29.bossesKilled/8;if(run.v29.id==='endless')return Math.min(1,run.time/1200);return r.duration?Math.min(1,run.time/r.duration):0}
function v29ObjectiveText(){if(!run?.v29)return'—';let id=run.v29.id,r=run.v29.rule;if(id==='bossrush')return run.v29.bossesKilled+'/8 Boss';if(id==='tower')return '第'+(save.modeStats.tower.floor||1)+'层 · '+(run.boss?'Boss战':'推进中');if(id==='endless')return fmt(run.time)+' · '+run.kills+'击杀';return fmt(run.time)+' / '+fmt(r.duration)}
function v29BattleUI(){
 if(!run?.active||!run.v29)return;let m=V29_MODES[run.v29.id],r=run.v29.rule,el=document.getElementById('v29BattleMode');if(!el)return;el.textContent=m.name;
 let target='坚持 '+(r.duration?fmt(r.duration):'无限');if(run.v29.id==='bossrush')target='连续击败8名Boss';if(run.v29.id==='tower')target='第 '+(save.modeStats.tower.floor||1)+' 层 · 击败守层Boss';if(run.v29.id==='endless')target='尽可能生存，10分钟后可撤离';
 document.getElementById('v29BattleObjective').innerHTML='<div class="modeObjRow"><span>核心目标</span><b>'+target+'</b></div><div class="modeObjRow"><span>模式奖励</span><b>×'+r.reward.toFixed(2)+' · 徽记 '+(run.v29.id==='endless'?'动态':r.tokens)+'</b></div><div class="modeObjRow"><span>进度</span><b>'+v29ObjectiveText()+'</b></div>';
 document.getElementById('v29ModeProgress').style.width=(v29Progress()*100)+'%';let act=document.getElementById('v29ModeAction');act.style.display=(run.v29.id==='endless'&&run.time>=600)?'block':'none';let badge=document.getElementById('v29ModeBadge');if(badge)badge.textContent=m.name.replace('模式','')+' · '+v29ObjectiveText()
}
function v29ManualExit(){if(run?.v29?.id!=='endless'||run.time<600)return;finishRun(true,'主动撤离 · 无尽成绩已保存')}

const _v29Interval=v19SpawnInterval;v19SpawnInterval=function(){let base=_v29Interval(),r=run?.v29?.rule||v29Rule();return base/Math.max(.12,r.spawn||1)};
const _v29Elite=v19EliteChance;v19EliteChance=function(){let c=_v29Elite();if(run?.v29?.id==='daily'&&run.v29.daily?.elite)c*=run.v29.daily.elite;if(run?.v29?.id==='abyss')c*=1.55;return Math.min(.42,c)};
const _v29Enemy=spawnEnemy;spawnEnemy=function(opts={}){let before=enemies.length,z=_v29Enemy(opts),r=run?.v29?.rule;if(r&&enemies.length>before)for(let i=before;i<enemies.length;i++){let e=enemies[i];if(!e._v29Scaled){e.hp*=r.hp;e.maxHp*=r.hp;e.damage*=r.dmg;e.speed*=r.speed;e._v29Scaled=true}}return z};

function v29SpawnBossId(id){if(!run?.active||run.boss)return;let old=save.selectedStage;run.bossDefeated=false;run.v26BossLootShown=false;save.selectedStage=V29_BOSS_STAGE[id]||old;spawnBoss();save.selectedStage=old;if(run.boss){let r=run.v29?.rule||v29Rule();run.boss.hp*=r.hp;run.boss.maxHp*=r.hp;run.v29.lastBossSeen=id}}
function v29BossForTower(){return V29_BOSS_ORDER[((save.modeStats.tower.floor||1)-1)%V29_BOSS_ORDER.length]}
function v29BossForStage(){return selectedStageInfo().stage[4]||'B001'}
function v29ApplyMode(){if(!run?.v29)v29RuntimeInit();let id=run.v29.id,d=run.v29.daily;if(id==='daily'&&d?.player){if(d.player.atk)player.atk*=1+d.player.atk;if(d.player.hp){player.maxHp*=1+d.player.hp;player.hp=player.maxHp}}if(id==='abyss'){player.maxHp*=.92;player.hp=player.maxHp}v29BattleUI()}

const _v29Pet=v27PetCast;v27PetCast=function(){let before=player.hp;_v29Pet();if(run?.v29?.id==='abyss'&&player.hp>before)player.hp=before+(player.hp-before)*.5};

function v29Update(dt){
 if(!run?.active||run.paused||!run.v29)return;let id=run.v29.id,r=run.v29.rule;
 if(run.v29.lastBossSeen&&!run.boss&&run.bossDefeated&&run.v29.countedBoss!==run.v29.lastBossSeen){run.v29.countedBoss=run.v29.lastBossSeen;run.v29.bossesKilled++}
 if(id==='bossrush'){
   if(!run.boss&&!document.getElementById('v26LootOverlay')?.classList.contains('show')){if(run.v29.bossesKilled>=8)return finishRun(true,'Boss Rush · 8名首领全部击败');v29SpawnBossId(V29_BOSS_ORDER[run.v29.bossesKilled])}
   if(run.time>=r.duration)return finishRun(false,'Boss Rush超时 · '+run.v29.bossesKilled+'/8')
 }else if(id==='tower'){
   if(run.time>=r.bossAt&&!run.boss&&!run.bossDefeated)v29SpawnBossId(v29BossForTower());
   if(run.bossDefeated&&run.v29.bossesKilled>=1)return finishRun(true,'万界塔第'+(save.modeStats.tower.floor||1)+'层通关');
   if(run.time>=r.duration)return finishRun(false,'守层Boss未能及时击破')
 }else if(id==='endless'){
   let milestone=Math.floor(run.time/600);if(milestone>=1&&milestone>run.v29.endlessBossMilestone&&!run.boss){run.v29.endlessBossMilestone=milestone;run.bossDefeated=false;run.v29.countedBoss=null;v29SpawnBossId(V29_BOSS_ORDER[(milestone-1)%V29_BOSS_ORDER.length])}
 }else{
   if(r.bossAt!=null&&run.time>=r.bossAt&&!run.boss&&!run.bossDefeated&&(id!=='story'||selectedStageInfo().stage[2]))v29SpawnBossId(v29BossForStage());
   if(r.duration&&run.time>=r.duration){if(run.boss)return finishRun(false,V29_MODES[id].name+'时间到达但Boss仍存活');return finishRun(true,V29_MODES[id].name+'目标完成')}
 }
 run.v29.score=Math.round(run.kills+(run.eliteKills||0)*35+run.v29.bossesKilled*600+(run.maxCombo||0)*2+run.time*.15);v29BattleUI()
}
const _v29Update=updateRun;updateRun=function(dt){_v29Update(dt);v29Update(dt)};

const _v29Finish=finishRun;
finishRun=function(victory,reason){
 if(!run?.active)return;let id=run?.v29?.id||save.mode||'story';
 if(id!=='story'&&(String(reason).includes('20分钟到达')||String(reason).includes('坚持20分钟')))return;
 let si=selectedStageInfo(),oldStars=save.chapters[si.chapter]?.stars?.[si.stage[0]]||0;_v29Finish(victory,reason);if(!lastResult)return;
 v29Ensure();let rule=run?.v29?.rule||v29Rule(id),ms=save.modeStats[id],score=run?.v29?.score||0,bosses=run?.v29?.bossesKilled||0;
 if(id!=='story'||!victory){if(save.chapters[si.chapter]?.stars)save.chapters[si.chapter].stars[si.stage[0]]=oldStars;lastResult.old=oldStars;lastResult.newStars=oldStars;if(!victory)lastResult.stars=0}
 let base=lastResult.gold||0,extra=Math.max(0,Math.round(base*((rule.reward||1)-1))),tokens=rule.tokens||0;if(id==='endless')tokens=Math.max(2,Math.floor(lastResult.time/300)*2+bosses*2);if(!victory)tokens=Math.floor(tokens*.35);
 save.gold+=extra;lastResult.gold+=extra;save.modeTokens+=tokens;ms.runs=(ms.runs||0)+1;if(victory)ms.wins=(ms.wins||0)+1;ms.bestKills=Math.max(ms.bestKills||0,lastResult.kills||0);ms.bestScore=Math.max(ms.bestScore||0,score);
 if(victory&&id!=='endless'&&(ms.bestTime===0||lastResult.time<ms.bestTime))ms.bestTime=lastResult.time;if(id==='endless')ms.bestTime=Math.max(ms.bestTime||0,lastResult.time);if(id==='bossrush')ms.bestBosses=Math.max(ms.bestBosses||0,bosses);
 if(id==='tower'&&victory){let floor=ms.floor||1;ms.bestFloor=Math.max(ms.bestFloor||1,floor);ms.floor=floor+1}if(id==='daily'){if(ms.lastDate!==v29DateKey()){ms.lastDate=v29DateKey();ms.bestScore=score}else ms.bestScore=Math.max(ms.bestScore||0,score)}
 lastResult.modeId=id;lastResult.modeName=V29_MODES[id].name;lastResult.modeRewardMult=rule.reward;lastResult.modeExtraGold=extra;lastResult.modeTokens=tokens;lastResult.modeScore=score;lastResult.modeBosses=bosses;
 localStorage.setItem(SAVE_KEY,JSON.stringify(save));if(typeof snapshotActiveSlot==='function')snapshotActiveSlot();renderAll();renderResult()
}
const _v29Result=renderResult;renderResult=function(){_v29Result();if(!lastResult||!lastResult.modeName)return;document.getElementById('resultTitle').textContent=lastResult.modeName+' · '+(lastResult.victory?'完成':'失败');let rows=document.getElementById('resultRows');if(rows)rows.innerHTML+='<div class="resultRow"><span>游戏模式</span><b>'+lastResult.modeName+'</b></div><div class="resultRow"><span>模式评分</span><b>'+lastResult.modeScore+'</b></div><div class="resultRow"><span>奖励倍率</span><b>×'+Number(lastResult.modeRewardMult||1).toFixed(2)+'</b></div><div class="resultRow"><span>模式额外金币</span><b>+'+(lastResult.modeExtraGold||0)+'</b></div><div class="resultRow"><span>万界徽记</span><b>+'+(lastResult.modeTokens||0)+'</b></div>'+(lastResult.modeId==='bossrush'?'<div class="resultRow"><span>Boss击破</span><b>'+lastResult.modeBosses+'/8</b></div>':'');document.getElementById('resStars').textContent=lastResult.modeId==='story'?('★'.repeat(lastResult.stars)+'☆'.repeat(Math.max(0,3-lastResult.stars))):'MODE'};

let v29LoadingTimer=null;
startBattle=function(){
 if(v29LoadingTimer)return;v29Ensure();let [ok,why]=v29Unlocked(save.mode);if(!ok){toast(why);go('modes');return}v27EnsureInventory();v26MigrateGear();let si=selectedStageInfo(),screen=document.getElementById('loadingScreen'),fill=document.getElementById('loadingFill'),s=save.heroes[save.hero],rule=v29Rule();
 document.getElementById('loadingStage').textContent=V29_MODES[save.mode].name+' · '+CHAPTERS[si.chapter].name+' · '+si.stage[1];document.getElementById('loadingHero').textContent=HEROES[save.hero].name+' Lv.'+s.level+' · '+s.star+'★ · 奖励×'+rule.reward.toFixed(2);document.getElementById('loadingTip').textContent=save.mode==='daily'?('今日挑战：'+v29Daily().name+' · '+v29Daily().desc):V29_MODES[save.mode].desc;fill.style.width='0%';document.getElementById('loadingProgress').textContent='0%';screen.classList.add('show');let p=0;
 v29LoadingTimer=setInterval(()=>{p=Math.min(100,p+19+Math.floor(Math.random()*14));fill.style.width=p+'%';document.getElementById('loadingProgress').textContent=p+'%';if(p>=100){clearInterval(v29LoadingTimer);v29LoadingTimer=null;setTimeout(()=>{screen.classList.remove('show');_v21_startBattle();if(run?.active){v23Init();v24RuntimeInit();v26ApplyLoadout();v27Apply();v28Apply();v29RuntimeInit();v29ApplyMode();run.v26BossLootShown=false;renderHeroMechanic();renderV24Runtime();v25Ensure();renderV26BattleGear();renderV27Battle();v28Battle();v29BattleUI();hint(V29_MODES[save.mode].name+' · '+v29ObjectiveText())}V21Audio.tone(240,.1,'triangle',.035,160)},100)}},65)
}

const _v29Go=go;go=function(id){_v29Go(id);if(id==='modes'){document.getElementById('pageTitle').textContent='游戏模式';v29RenderModes()}};
const _v29Top=renderTop;renderTop=function(){v29Ensure();_v29Top();let e=document.getElementById('topMode');if(e)e.textContent=V29_MODES[save.mode].name.replace('模式','')};
const _v29All=renderAll;renderAll=function(){_v29All();v29RenderModes()};
const _v29Boot=v20Boot;v20Boot=function(){v29Ensure();_v29Boot();v29RenderModes();renderTop()}
