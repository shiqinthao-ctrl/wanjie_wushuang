/* result */
function finishRun(victory,reason){
 if(!run.active)return;run.active=false;run.paused=true;finalizeDrops();const si=selectedStageInfo(),old=save.chapters[si.chapter].stars[si.stage[0]]||0,stars=victory?(player.hp/player.maxHp>.55?3:2):1,newStars=Math.max(old,stars),gold=victory?si.stage[3]+stars*100:Math.floor(si.stage[3]*.35),masteryGain=Math.max(5,Math.round(run.time/30+run.kills*.04));
 save.chapters[si.chapter].stars[si.stage[0]]=newStars;save.gold+=gold;save.heroes[save.hero].mastery+=masteryGain;save.stats.runs++;save.stats.kills+=run.kills;if(si.stage[2]&&victory)save.stats.bossKills++;
 lastResult={victory,reason,stage:si.stage,chapter:si.chapter,time:run.time,kills:run.kills,stars,gold,old,newStars,masteryGain,drops:[...run.drops],evo:Object.keys(run.evolved).filter(x=>run.evolved[x]).length,fusion:Object.keys(run.fused).filter(x=>run.fused[x]).length,maxCombo:run.maxCombo,damageBy:{...run.damageBy},eliteKills:run.eliteKills};
 persist();renderResult();go('result')
}
function renderResult(){
 if(!lastResult)return;const r=lastResult;document.getElementById('resultState').textContent=r.victory?'VICTORY':'DEFEAT';document.getElementById('resultTitle').textContent=r.stage[1]+' · '+(r.victory?'胜利':'战败');document.getElementById('resultReason').textContent=r.reason;document.getElementById('resTime').textContent=fmt(r.time);document.getElementById('resKills').textContent=r.kills;document.getElementById('resStars').textContent='★'.repeat(r.stars)+'☆'.repeat(3-r.stars);document.getElementById('resGold').textContent='+'+r.gold;
 document.getElementById('resultRows').innerHTML='<div class="resultRow"><span>章节星</span><b>'+r.old+' → '+r.newStars+'</b></div><div class="resultRow"><span>英雄熟练度</span><b>+'+r.masteryGain+'</b></div><div class="resultRow"><span>本局进化</span><b>'+r.evo+'</b></div><div class="resultRow"><span>本局融合</span><b>'+r.fusion+'</b></div><div class="resultRow"><span>精英击杀</span><b>'+r.eliteKills+'</b></div><div class="resultRow"><span>最大连击</span><b>'+r.maxCombo+'</b></div>';
 const dg=document.getElementById('dropGrid');dg.innerHTML='';if(r.drops.length){r.drops.forEach(d=>{const x=document.createElement('div');x.className='dropCard';x.innerHTML='<b>'+d.name+'</b><small>'+d.id+' · '+d.rarity+' · '+d.source+'</small>';dg.appendChild(x)})}else dg.innerHTML='<div class="tiny">本局无装备掉落</div>';
 renderDamageList('resultDamage',r.damageBy)
}

function renderSettingsToggles(){['shake','numbers','particles','vignette'].forEach(k=>{const el=document.getElementById(k+'Toggle');if(el)el.classList.toggle('on',!!save.settings[k])})}
function renderAll(){recomputeWorldUnlocks();renderTop();renderHeroes();renderLoadout();renderBuild();renderWorld();renderSettingsToggles();if(document.getElementById('battle').classList.contains('active'))renderRunSide()}
function loop(now){const dt=Math.min(.034,(now-last)/1000||0);last=now;updateRun(dt);drawRun();requestAnimationFrame(loop)}
requestAnimationFrame(loop);
renderAll();resizeArena();
