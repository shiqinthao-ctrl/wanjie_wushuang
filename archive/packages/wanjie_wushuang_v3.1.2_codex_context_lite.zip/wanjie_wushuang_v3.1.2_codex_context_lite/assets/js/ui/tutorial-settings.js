/* tutorial/settings */
function showTutorial(){run.paused=true;document.getElementById('tutorialOverlay').classList.add('show');renderTutorial()}
function renderTutorial(){document.getElementById('tutorialTitle').textContent=TUTORIAL[tutorialStep][0];document.getElementById('tutorialText').textContent=TUTORIAL[tutorialStep][1]}
function nextTutorial(){tutorialStep++;if(tutorialStep>=TUTORIAL.length){skipTutorial();return}renderTutorial()}
function skipTutorial(){save.settings.tutorialSeen=true;persist();document.getElementById('tutorialOverlay').classList.remove('show');run.paused=false}
function togglePause(){if(!run.active)return;run.paused=!run.paused;document.getElementById('pauseOverlay').classList.toggle('show',run.paused)}
function toggleSetting(key){save.settings[key]=!save.settings[key];document.getElementById(key+'Toggle').classList.toggle('on',save.settings[key]);persist()}
