/* world */
function renderWorld(){
 recomputeWorldUnlocks();const wm=document.getElementById('worldMap');wm.innerHTML='';const ids=['ST001','ST003','ST004'];
 for(let i=0;i<ids.length-1;i++){const a=CHAPTERS[ids[i]].pos,b=CHAPTERS[ids[i+1]].pos,dx=b[0]-a[0],dy=b[1]-a[1],len=Math.sqrt(dx*dx+dy*dy),angle=Math.atan2(dy,dx)*180/Math.PI,r=document.createElement('div');r.className='route '+(!CHAPTERS[ids[i+1]].unlock?'locked':'');r.style.left=a[0]+'%';r.style.top=a[1]+'%';r.style.width=len+'%';r.style.transform='rotate('+angle+'deg)';wm.appendChild(r)}
 ids.forEach((id,i)=>{const c=CHAPTERS[id],n=document.createElement('div');n.className='chapterNode '+(!c.unlock?'locked':'');n.style.left=c.pos[0]+'%';n.style.top=c.pos[1]+'%';n.innerHTML='<div class="nodeOrb">'+(i+1)+'</div><h4>'+c.name+'</h4><small>'+id+' · '+chapterStars(id)+'/12星</small>';n.onclick=()=>selectWorldChapter(id);wm.appendChild(n)});
 renderStageList()
}
function selectWorldChapter(id){if(!CHAPTERS[id].unlock){toast('章节未解锁');return}save.selectedChapter=id;const first=CHAPTERS[id].stages.find((st,i)=>i===0||((save.chapters[id].stars[CHAPTERS[id].stages[i-1][0]]||0)>0));if(first)save.selectedStage=first[0];persist()}
function renderStageList(){
 const cid=save.selectedChapter,c=CHAPTERS[cid];document.getElementById('worldChapterId').textContent=cid;document.getElementById('worldChapterName').textContent=c.name;document.getElementById('worldChapterDesc').textContent=c.desc;document.getElementById('mapMechanic').innerHTML='<b>'+c.mechanic.split('：')[0]+'</b><small>'+c.mechanic+'</small>';const g=document.getElementById('stageList');g.innerHTML='';
 c.stages.forEach((st,i)=>{const unlocked=i===0||(save.chapters[cid].stars[c.stages[i-1][0]]||0)>0,stars=save.chapters[cid].stars[st[0]]||0,d=document.createElement('div');d.className='stageRow '+(save.selectedStage===st[0]?'active ':'')+(!unlocked?'locked':'');d.innerHTML='<b>'+st[0]+' · '+st[1]+'</b><small>'+('★'.repeat(stars)+'☆'.repeat(3-stars))+' · '+(st[2]?'Boss节点':'普通节点')+' · '+st[4]+'</small>';d.onclick=()=>{if(!unlocked){toast('前置关卡未完成');return}save.selectedStage=st[0];persist()};g.appendChild(d)})
}
