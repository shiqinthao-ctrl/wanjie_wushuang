/* build */
function renderBuild(){
 document.getElementById('buildHeroName').textContent=HEROES[save.hero].name;renderBuildSlots('activeSlots',save.build.active,6);renderBuildSlots('passiveSlots',save.build.passive,6);document.getElementById('activeCount').textContent=save.build.active.length+'/6';document.getElementById('passiveCount').textContent=save.build.passive.length+'/6';
 const pg=document.getElementById('presetGrid');pg.innerHTML='';HEROES[save.hero].presets.forEach((p,i)=>{const d=document.createElement('div');d.className='preset';d.innerHTML='<div class="eyebrow">PRESET '+(i+1)+'</div><h4>'+p[0]+'</h4><p>主动：'+p[1].map(skillName).join(' / ')+'<br>被动：'+p[2].map(skillName).join(' / ')+'</p><button class="btn gold" style="width:100%" onclick="applyPreset('+i+')">应用</button>';pg.appendChild(d)});
 const all=[...new Set(Object.values(HEROES).flatMap(h=>h.presets.flatMap(p=>[...p[1],...p[2]])))],g=document.getElementById('skillPickGrid');g.innerHTML='';
 all.forEach(id=>{const active=save.build.active.includes(id)||save.build.passive.includes(id),d=document.createElement('div');d.className='pick '+(active?'active':'');d.innerHTML='<b>'+skillName(id)+'</b><small>'+id+'</small>';d.onclick=()=>toggleBuild(id);g.appendChild(d)})
}
function renderBuildSlots(elId,arr,limit){const g=document.getElementById(elId);g.innerHTML='';for(let i=0;i<limit;i++){const id=arr[i],d=document.createElement('div');d.className='buildSlot '+(id?'filled':'')+(id&&reachableBuildEvos().some(e=>EVOS[e][1]===id)?' ready':'');d.innerHTML=id?'<div class="skillIcon">'+glyph(id)+'</div><b>'+skillName(id)+'</b><small>'+id+'</small>':'<div class="tiny">空槽</div>';if(id)d.onclick=()=>toggleBuild(id);g.appendChild(d)}}
function toggleBuild(id){const passive=id.startsWith('P'),arr=passive?save.build.passive:save.build.active,idx=arr.indexOf(id);if(idx>=0)arr.splice(idx,1);else{if(arr.length>=6){toast((passive?'被动':'主动')+'槽已满');return}arr.push(id)}persist()}
function applyPreset(i){const p=HEROES[save.hero].presets[i];save.build.active=[...p[1]];save.build.passive=[...p[2]];persist();toast('已应用 '+p[0])}
function clearBuild(){save.build.active=[];save.build.passive=[];persist()}
