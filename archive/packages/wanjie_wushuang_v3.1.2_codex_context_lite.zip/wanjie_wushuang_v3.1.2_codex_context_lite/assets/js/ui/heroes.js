/* heroes */
function renderHeroes(){
 const g=document.getElementById('heroGrid');g.innerHTML='';
 Object.entries(HEROES).forEach(([id,h])=>{const s=save.heroes[id],st=heroStats(id),d=document.createElement('div');d.className='card heroCard '+(save.hero===id?'selected ':'')+(!s.unlocked?'locked':'');d.innerHTML='<div class="portrait"></div><div class="eyebrow">'+id+'</div><h3>'+h.name+'</h3><div class="tags"><span class="tag">'+h.skill+'</span><span class="tag">'+h.ult+'</span></div><div class="heroStats"><div><small>HP</small><b>'+st.hp+'</b></div><div><small>ATK</small><b>'+st.atk+'</b></div><div><small>Lv.</small><b>'+s.level+'</b></div></div><div class="actions"><button class="btn '+(s.unlocked?'primary':'gold')+'" onclick="selectHero(\''+id+'\')">'+(s.unlocked?'选择':'解锁 '+h.unlock+'金')+'</button></div>';g.appendChild(d)})
}
function selectHero(id){const h=HEROES[id],s=save.heroes[id];if(!s.unlocked){if(save.gold<h.unlock){toast('金币不足');return}save.gold-=h.unlock;s.unlocked=true}save.hero=id;save.build.active=[...h.presets[0][1]];save.build.passive=[...h.presets[0][2]];persist();toast('已选择 '+h.name);go('loadout')}
