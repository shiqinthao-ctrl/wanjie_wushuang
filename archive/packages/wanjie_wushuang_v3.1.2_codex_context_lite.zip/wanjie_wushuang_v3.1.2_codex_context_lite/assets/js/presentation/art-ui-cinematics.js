/* ================= V2.2 ART UI & CINEMATICS ================= */
const V22_ASSET_MANIFEST={
 hero:{
  H001:{portrait:'assets/heroes/H001_portrait.webp',sheet:'assets/heroes/H001_sheet.webp',element:'fire'},
  H002:{portrait:'assets/heroes/H002_portrait.webp',sheet:'assets/heroes/H002_sheet.webp',element:'lightning'},
  H007:{portrait:'assets/heroes/H007_portrait.webp',sheet:'assets/heroes/H007_sheet.webp',element:'physical'},
  H010:{portrait:'assets/heroes/H010_portrait.webp',sheet:'assets/heroes/H010_sheet.webp',element:'fire'},
  H012:{portrait:'assets/heroes/H012_portrait.webp',sheet:'assets/heroes/H012_sheet.webp',element:'shadow'},
  H019:{portrait:'assets/heroes/H019_portrait.webp',sheet:'assets/heroes/H019_sheet.webp',element:'ki'}
 },
 bosses:Object.fromEntries(Object.keys(BOSSES).map(id=>[id,{portrait:'assets/bosses/'+id+'_portrait.webp',sheet:'assets/bosses/'+id+'_sheet.webp'}])),
 skills:{base:'assets/skills/{ID}.webp'},
 maps:{ST001:'assets/maps/ST001_thumb.webp',ST003:'assets/maps/ST003_thumb.webp',ST004:'assets/maps/ST004_thumb.webp'}
};
function v22Element(id){
 if(id.startsWith('P'))return'passive';
 if(['A011','A021','A027','A003','A042','A054','A019','S002','A063'].includes(id))return'fire';
 if(['A002','A013','A022','A041','A051','A062','S003'].includes(id))return'lightning';
 if(['A026','A045'].includes(id))return'wind';
 if(['A015','A053','A070','A072','A073','S001','A007'].includes(id))return'shadow';
 if(['A014','A030','A049','A060','A068','S018'].includes(id))return'ki';
 return'physical'
}
function v22SkillIconHTML(id,cls=''){
 const t=(id?.startsWith('E')||id?.startsWith('SE'))?'evo':id?.startsWith('F')?'fusion':v22Element(id);
 return '<div class="skillArtIcon '+t+' '+cls+'"><span>'+glyph(id)+'</span></div>'
}
function v22HeroAvatarHTML(id,size=''){
 const h=HEROES[id],hair={H001:'#321c1d',H002:'#242638',H007:'#4a321c',H010:'#351b1b',H012:'#1e1a31',H019:'#1c3438'}[id]||'#27202a';
 return '<div class="heroAvatar '+size+'" style="--avatar-color:'+h.color+';--avatar-hair:'+hair+'"><div class="hair"></div><div class="mark">'+id.slice(1)+'</div></div>'
}
function v22RarityClass(r){return r==='gold'?'rarity-gold':r==='purple'?'rarity-purple':r==='mythic'?'rarity-mythic':'rarity-blue'}
function v22RarityName(r){return r==='gold'?'传说':r==='purple'?'史诗':r==='mythic'?'神话':'稀有'}

/* Hero list: art identity replaces generic portrait feel */
const _v22_renderHeroes=renderHeroes;
renderHeroes=function(){
 const g=document.getElementById('heroGrid');g.innerHTML='';
 Object.entries(HEROES).forEach(([id,h])=>{
   const s=save.heroes[id],st=heroStats(id),d=document.createElement('div');
   d.className='card heroCard '+(save.hero===id?'selected ':'')+(!s.unlocked?'locked':'');
   d.innerHTML='<div class="ornament tl"></div><div class="ornament br"></div><div class="heroIdentity">'+v22HeroAvatarHTML(id)+'<div><div class="eyebrow">'+id+'</div><h3>'+h.name+'</h3><small>'+h.skill+' · '+h.ult+'</small></div></div>'+
   '<div class="tags"><span class="tag">'+h.skill+'</span><span class="tag">'+h.ult+'</span></div>'+
   '<div class="heroStats"><div><small>HP</small><b>'+st.hp+'</b></div><div><small>ATK</small><b>'+st.atk+'</b></div><div><small>Lv.</small><b>'+s.level+'</b></div></div>'+
   '<div class="actions"><button class="btn '+(s.unlocked?'primary':'gold')+'" onclick="selectHero(\''+id+'\')">'+(s.unlocked?'选择':'解锁 '+h.unlock+'金')+'</button></div>';
   g.appendChild(d)
 })
};

/* Build slots now use visual skill icons */
renderBuildSlots=function(elId,arr,limit){
 const g=document.getElementById(elId);g.innerHTML='';
 for(let i=0;i<limit;i++){
   const id=arr[i],d=document.createElement('div');d.className='buildSlot '+(id?'filled':'')+(id&&reachableBuildEvos().some(e=>EVOS[e][1]===id)?' ready':'');
   d.innerHTML=id?v22SkillIconHTML(id)+'<b>'+skillName(id)+'</b><small>'+id+'</small>':'<div class="tiny">空槽</div>';
   if(id)d.onclick=()=>toggleBuild(id);g.appendChild(d)
 }
};

/* Loadout: rarity art frames */
const _v22_renderLoadout=renderLoadout;
renderLoadout=function(){
 _v22_renderLoadout();
 document.querySelectorAll('#gearGrid .itemCard').forEach(card=>{
   const id=card.querySelector('.eyebrow')?.textContent.trim(),g=GEAR[id];if(!g)return;
   card.classList.add(v22RarityClass(g.rarity));card.style.position='relative';
   const rib=document.createElement('div');rib.className='rarityRibbon';rib.textContent=v22RarityName(g.rarity);card.appendChild(rib)
 });
};

/* World card gets visual thumbnails */
const _v22_renderStageList=renderStageList;
renderStageList=function(){
 _v22_renderStageList();
 const side=document.getElementById('worldChapterName')?.parentElement;if(!side)return;
 let old=side.querySelector('.mapThumb');if(old)old.remove();
 const cid=save.selectedChapter,thumb=document.createElement('div');thumb.className='mapThumb '+cid.toLowerCase();
 thumb.innerHTML='<div class="mapLabel">'+cid+' · '+CHAPTERS[cid].name+'</div>';
 const title=document.getElementById('worldChapterId');title.parentElement.insertBefore(thumb,title)
};

/* Run/build HUD art icons */
renderHudSlots=function(){
 const g=document.getElementById('hudSlots');if(!g)return;g.innerHTML='';
 Object.entries(run.skills).forEach(([id,lv])=>{
   const ev=Object.keys(run.evolved).find(e=>run.evolved[e]&&EVOS[e][1]===id),show=ev||id,d=document.createElement('div');
   d.className='hudSlot '+(ev?'evo':'');d.innerHTML=v22SkillIconHTML(show)+'<em>'+lv+'</em>';g.appendChild(d)
 });
 Object.keys(run.fused).filter(id=>run.fused[id]).forEach(id=>{const d=document.createElement('div');d.className='hudSlot fusion';d.innerHTML=v22SkillIconHTML(id)+'<em>F</em>';g.appendChild(d)})
};

/* Boss portrait beside boss bar */
function v22EnsureBossPortrait(){
 const bar=document.getElementById('bossBar');if(!bar||bar.querySelector('.bossPortrait'))return;
 const p=document.createElement('div');p.className='bossPortrait';p.innerHTML='<div class="horn"></div>';bar.insertBefore(p,bar.firstChild)
}
v22EnsureBossPortrait();

/* Evolution / fusion cinematic */
function v22PlayEvolution(id,type){
 const c=document.getElementById('evolutionCinematic'),core=document.getElementById('evoCore');if(!c)return;
 core.classList.toggle('fusion',type==='fusion');
 document.getElementById('evoIconBig').textContent=glyph(id);
 document.getElementById('evoEyebrow').textContent=type==='fusion'?'SKILL FUSION':'SKILL EVOLUTION';
 document.getElementById('evoTitle').textContent=skillName(id);
 let sub=id;
 if(type==='fusion'&&FUSIONS[id])sub=FUSIONS[id][1]+' + '+FUSIONS[id][2]+' → '+id;
 if(type==='evo'&&EVOS[id])sub=EVOS[id][1]+' + '+EVOS[id][2]+' → '+id;
 document.getElementById('evoSub').textContent=sub;
 c.classList.add('show');V21Audio.skill();setTimeout(()=>c.classList.remove('show'),1250)
}
const _v22_pickChest=pickChest;
pickChest=function(r){_v22_pickChest(r);if(r?.id&&(r.type==='evo'||r.type==='fusion'))v22PlayEvolution(r.id,r.type);if(r?.type==='gear')v22LootToast('装备获得 · '+(run.drops.at(-1)?.name||'新装备'))};

/* Boss intro cinematic */
function v22BossIntro(b){
 const cfg=BOSSES[b.id],el=document.getElementById('bossIntro');if(!el)return;
 document.getElementById('bossIntroTitle').textContent=b.id+' · '+cfg.name;
 document.getElementById('bossIntroStyle').textContent=cfg.style+' · '+cfg.skills.join(' / ');
 document.getElementById('bossIntroPortrait').style.setProperty('--boss-color',cfg.color);
 el.classList.add('show');setTimeout(()=>el.classList.remove('show'),1350)
}
const _v22_spawnBoss=spawnBoss;
spawnBoss=function(){_v22_spawnBoss();if(run.boss){v22EnsureBossPortrait();const p=document.querySelector('#bossBar .bossPortrait');if(p)p.style.setProperty('--boss-color',run.boss.color);v22BossIntro(run.boss)}}

/* Loot feedback */
function v22LootToast(text){
 const g=document.getElementById('lootToast');if(!g)return;const d=document.createElement('div');d.className='lootLine';d.textContent=text;g.appendChild(d);setTimeout(()=>d.remove(),2500)
}
const _v22_makeGearDrop=makeGearDrop;
makeGearDrop=function(source){const d=_v22_makeGearDrop(source);setTimeout(()=>v22LootToast(v22RarityName(d.rarity)+' · '+d.name),0);return d};

/* Result drops get rarity frames */
const _v22_renderResult=renderResult;
renderResult=function(){
 _v22_renderResult();
 document.querySelectorAll('#dropGrid .dropCard').forEach(card=>{
   const txt=card.textContent;const id=(txt.match(/EQ[WAX]\d+/)||[])[0],g=GEAR[id];if(g)card.classList.add(v22RarityClass(g.rarity))
 })
};

/* Draw upgrades: more stylized silhouettes and weapon trails */
const _v22_v21DrawHero=v21DrawHero;
v21DrawHero=function(){
 const h=HEROES[save.hero],x=player.x,y=player.y,c=h.color;v21Shadow(x,y,19,7,.36);ctx.save();ctx.translate(x,y);
 ctx.shadowBlur=player.inv>0?26:20;ctx.shadowColor=player.inv>0?'#fff5ce':c;
 // legs
 ctx.strokeStyle='#20232b';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(-4,9);ctx.lineTo(-7,18);ctx.moveTo(4,9);ctx.lineTo(7,18);ctx.stroke();
 // coat/body
 ctx.fillStyle=c;ctx.beginPath();ctx.moveTo(-10,-5);ctx.quadraticCurveTo(0,-10,10,-5);ctx.lineTo(13,10);ctx.lineTo(5,16);ctx.lineTo(0,12);ctx.lineTo(-5,16);ctx.lineTo(-13,10);ctx.closePath();ctx.fill();
 // head/hair
 ctx.fillStyle='#d7a477';ctx.beginPath();ctx.arc(0,-15,7,0,Math.PI*2);ctx.fill();ctx.fillStyle={H001:'#351d1e',H002:'#25263b',H007:'#51351e',H010:'#361c1c',H012:'#201a32',H019:'#18343a'}[save.hero];ctx.beginPath();ctx.arc(0,-18,8,Math.PI,Math.PI*2);ctx.fill();
 // weapon / energy
 ctx.strokeStyle='#ffe0a0';ctx.lineWidth=3.5;ctx.beginPath();ctx.moveTo(7,-1);ctx.lineTo(21,-14);ctx.stroke();
 ctx.globalAlpha=.28;ctx.strokeStyle=c;ctx.lineWidth=7;ctx.beginPath();ctx.arc(9,-2,20,-1.1,.3);ctx.stroke();ctx.globalAlpha=1;
 ctx.restore()
};
const _v22_v21DrawEnemy=v21DrawEnemy;
v21DrawEnemy=function(e){_v22_v21DrawEnemy(e);if(e.elite&&e.affixes?.length){ctx.save();ctx.font='700 7px Inter';ctx.textAlign='center';ctx.fillStyle='#f3c66c';ctx.fillText(e.affixes.map(x=>x[0].toUpperCase()).join('·'),e.x,e.y-e.r-9);ctx.restore()}};

/* Topbar current hero art badge */
function v22InjectTopAvatar(){
 const top=document.querySelector('.user');if(!top)return;let old=document.getElementById('v22TopHeroAvatar');if(old)old.remove();
 const w=document.createElement('div');w.id='v22TopHeroAvatar';w.style.display='flex';w.style.alignItems='center';w.innerHTML=v22HeroAvatarHTML(save.hero);
 top.insertBefore(w,top.firstChild)
}
const _v22_renderTop=renderTop;
renderTop=function(){_v22_renderTop();v22InjectTopAvatar()};

/* Improve start title mark */
const titleMark=document.querySelector('.titleMark');
if(titleMark){
 const deco=document.createElement('div');deco.style.cssText='margin-top:14px;display:flex;gap:8px;flex-wrap:wrap';
 deco.innerHTML='<span class="tag hot">国潮热血</span><span class="tag">Roguelite</span><span class="tag">跨世界Build</span><span class="tag">20分钟一局</span>';
 titleMark.appendChild(deco)
}

/* Boot refresh */
const _v22_v20Boot=v20Boot;
v20Boot=function(){_v22_v20Boot();v22InjectTopAvatar();v22EnsureBossPortrait()}
