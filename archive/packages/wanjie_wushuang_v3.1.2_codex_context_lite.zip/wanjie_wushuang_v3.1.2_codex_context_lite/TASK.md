# TASK.md — V3.2 Phase 1A

## Goal
Introduce the `window.WW` root namespace for pure configuration only, without changing gameplay.

## Read
- `handoff/STATE.md`
- `docs/INDEX.md`
- Only the config/runtime files needed for this task.

## Do
1. Create `WW.config`.
2. Expose existing hero/skill/boss/stage/gear/rune/pet/mode config objects through `WW.config`.
3. Keep legacy globals as compatibility aliases.
4. Produce `docs/GLOBAL_RUNTIME_AUDIT.md` containing only:
   - config globals
   - state globals
   - functions overridden 2+ times
   - top 10 risky wrapper chains
5. Do not migrate `save`, `run`, `player`, `enemies`, `shots`.

## Done when
- Behavior is intended to remain unchanged.
- `npm run check`
- `npm run smoke`
- `npm run audit`
- `npm run context`
all pass.
