# 万界无双 V3.1.2 Codex Context-Lite

针对 Codex 413 / context limit 优化版。

## Codex 第一次打开项目
只发送：

> Read `AGENTS.md`, then execute `TASK.md`. Do not preload other docs.

不要把历史聊天或完整产品文档粘贴到提示词。

## 新线程续接
先让旧线程更新 `handoff/STATE.md`，然后新线程只发送：

> Read `AGENTS.md`, `handoff/STATE.md`, and `TASK.md`. Continue. Use `docs/INDEX.md` only when needed.

## 本地运行
```bash
npm run dev
```

## 验证
```bash
npm run check
npm run smoke
npm run audit
npm run context
```

## 文档结构
- `AGENTS.md`：每次自动需要的短规则
- `TASK.md`：唯一当前任务
- `handoff/STATE.md`：跨线程状态
- `docs/INDEX.md`：按需文档路由
- `docs/reference/`：完整参考资料，默认不读
- `tasks/`：后续任务包，默认不读
