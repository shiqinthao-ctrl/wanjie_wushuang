# docs/INDEX.md — read only what the task needs

Do not read every file.

| Need | Read |
|---|---|
| Product rules / IDs / gameplay baseline | `reference/PRODUCT_SPEC.md` |
| Definition of Done / regressions | `reference/ACCEPTANCE_CRITERIA.md` |
| Script order / architecture | `reference/ARCHITECTURE.md` |
| Future version roadmap | `reference/ROADMAP.md` |
| Codex usage conventions | `reference/CODEX_WORKFLOW.md` |
| Previous static validation | `reference/VALIDATION.md` |
| Current project state / last task | `../handoff/STATE.md` |
| Current implementation task | `../TASK.md` |

Rule: open the smallest relevant section/file; do not summarize unrelated documents.
