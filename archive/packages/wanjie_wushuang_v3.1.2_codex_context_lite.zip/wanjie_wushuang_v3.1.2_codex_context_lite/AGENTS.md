# AGENTS.md

## Always
- Do only the current task in `TASK.md`.
- Do NOT preload all docs. Read `docs/INDEX.md` only to find task-relevant references.
- Preserve Schema 30 saves, 0-star fresh saves, single settlement, non-story star isolation, and V3.0 safety fixes.
- Keep ordered script loading unless `TASK.md` explicitly scopes a migration.
- Prefer fixing/merging existing logic; do not add another version wrapper when avoidable.
- No public Debug UI. No new dependency unless the task explicitly requires it.

## Verify
Run before completion:
`npm run check && npm run smoke && npm run audit && npm run context`

## Finish
Update `handoff/STATE.md` with: changed files, tests, unresolved risk, next task.
Keep final response short.
