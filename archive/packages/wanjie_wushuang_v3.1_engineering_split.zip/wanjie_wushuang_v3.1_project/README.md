# 万界无双 V3.1 工程化拆分版

V3.1 的目标不是增加玩法，而是把 V3.0 单文件原型拆成可维护项目，同时保持原有脚本执行顺序与全局运行模型，降低一次性重构的回归风险。

## 运行

最简单：直接打开 `index.html`。

推荐本地 HTTP：

```bash
python -m http.server 8080
```

然后浏览器打开 `http://localhost:8080/`。

Windows 也可运行根目录的 `run_local_server.bat`。

## 目录

- `assets/css/app.css`：全部 UI / 战斗表现样式
- `assets/js/config/`：英雄、技能、关卡、敌人、默认存档等基础数据
- `assets/js/core/`：V3.0 稳定层与 V3.1 项目元数据
- `assets/js/combat/`：战斗引擎、英雄差异化、真实技能实体、Boss与地图交互
- `assets/js/systems/`：Director、存档、多模式、装备、符文宠物、长期成长
- `assets/js/ui/`：英雄、装备、Build、世界、教程设置、结算
- `assets/js/presentation/`：Loading、音频接口、视觉演出、头像/技能图标体系
- `docs/ARCHITECTURE.md`：加载顺序、依赖关系与下一轮重构建议

## 重要原则

V3.1 仍使用“按顺序加载的全局脚本”，这是刻意设计的过渡架构。它确保 V2.x/V3.0 大量 wrapper/override 逻辑不因 ES Module 作用域改变而失效。

下一阶段 V3.2 再逐步把全局状态迁移到 `window.WW` 命名空间，并把配置与运行时分离。
